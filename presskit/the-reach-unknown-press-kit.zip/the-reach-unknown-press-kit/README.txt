The Reach: Unknown - press kit
Mach Tuck Games LLC · https://machtuck.com/presskit/

Fact sheet
Studio: Mach Tuck Games LLC, an independent studio
Game: The Reach: Unknown
Genre: Persistent, first-person mech war, online
Status: In development
Platforms: Windows and Mac on Steam, in closed beta first; iOS and Android to follow
Price: Closed beta: free, through Steam Playtest. Open beta: $19.99 on Steam, in Early Access. Phone pricing later.
Release date: To be announced
Website: machtuck.com/thereach
Press contact: support@machtuck.com

Descriptions
One line
A persistent mech war: join one of five factions or fly alone as a Torrath mercenary, and every match you fight moves a front all pilots share.
Short
The Reach: Unknown is a persistent, first-person mech war. Pilots join one of five factions, or fly alone as a Torrath mercenary, and fight for ground on The Reach, the first home humanity has found since Earth failed. Every win and every loss shifts a front line that all pilots share, and clans of up to fifty pilots hold what they take.
Long
Earth was failing. An evacuation sent a probe to the nearest star, then a small crew to go ahead, then the Archive: a moving city of about twenty thousand people on a crossing of 32.63 years. The crew sent ahead landed on The Reach, built a settlement and called home. Then the logs stopped coming. Five factions were born aboard during the crossing, each with its own answer to why Earth failed, and each means to claim the new world.
The Reach: Unknown is the war that follows, fought from a full first-person cockpit. Mechs have mass, and every loadout has a price. Pilots join one of five factions or fly alone as a Torrath mercenary, and every win and every loss shifts a front line that all of them share. Clans of up to fifty pilots hold what they take. Rank comes from time served, hours flown and damage done, and it carries from season to season.
The game is in development at Mach Tuck Games, an independent studio, for Windows and Mac on Steam, with iOS and Android to follow. It is built to run for years.

Features
- Move the front. Every win and every loss shifts it on a map all pilots share. The Front opens as its own event after the closed beta begins.
- Feel the weight. Every fight is first person, from a full cockpit. Mechs have mass, and every loadout has a price.
- Honor counts. Valor is won one on one in Ranked, best of three, and your rank carries from season to season.
- Fly for a clan. Up to fifty pilots under one banner, who remember who showed up.
- Five factions, or none. Five decks of the Archive, each with its own answer to why Earth failed, or fly alone as a Torrath mercenary.
- Five lands on one river. Snow highlands, jungle, desert mesas, volcanic badlands and the settlement. A dust storm cuts the view to about a hundred yards, and on some days the volcano erupts.
See it for yourself: The Hangar, The Armory, The Physics.

For creators
Stream, record and monetise The Reach: Unknown freely. There is no embargo and no NDA.
- Show anything. What you see in the game is yours to show, whenever you like.
- Keep what you earn. Monetise your streams and videos however your platform allows.
- Use this kit. Everything on this page is free to use in your thumbnails, overlays and videos.
- Keys come later. Closed beta keys will come through Steam Playtest. Write to us and tell us where you post.

Contact
Press, creators and partners: support@machtuck.com.
Meet the pilots: our Discord.

Links
The game: https://machtuck.com/thereach/
The Hangar: https://machtuck.com/hangar/
The Armory: https://machtuck.com/armory/
The Physics: https://machtuck.com/physics/
Discord: https://discord.gg/akCxskKStX

Logos and art
The Reach: Unknown(TM) and the MT shield are trademarks of Mach Tuck Games LLC. Please use the logos as they are,
without changes. How we make our art: https://machtuck.com/art/
